<div id="social">
    <ul class="list-inline d-flex justify-content-end">
        <li class="list-inline-item mr-3">
            <a href="#" class="font-weight-bolder">
                English
            </a>
        </li>
        <li class="list-inline-item mr-3">
            <a href="#">
                <i class="fab fa-youtube"></i>
            </a>
        </li>
        <li class="list-inline-item mr-3">
            <a href="#">
                <i class="fab fa-instagram"></i>
            </a>
        </li>
        <li class="list-inline-item mr-3">
            <a href="#">
                <i class="fab fa-twitter"></i>
            </a>
        </li>
        <li class="list-inline-item mr-3">
            <a href="#">
                <i class="fab fa-snapchat-ghost"></i>
            </a>
        </li>
        <li class="list-inline-item mr-3">
            <a href="#">
                <i class="fab fa-facebook-f"></i>
            </a>
        </li>
    </ul>
</div>
