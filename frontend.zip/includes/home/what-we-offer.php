<div id="what-we-offer" class="bg-dark py-5 bg-cover" style="background-image: url('../../images/worker.jpg')">
	<div class="container">
		<h2 class="text-secondary fw-bold text-center responsive-header my-lg-6 my-md-5 my-4">ماذا نقدم لك؟</h2>

		<div class="row text-center text-md-left">
			<div class="col-lg-3 col-md-6 col-12 mb-4 text-center">
				<img src="../../images/about-1.png" class="img-fluid mb-3" alt="">
				<h4 class="offer-title text-white responsive-header fw-light">إصدار التأشيرات</h4>
			</div>
			<div class="col-lg-3 col-md-6 col-12 mb-4 text-center">
				<img src="../../images/about-2.png" class="img-fluid mb-3" alt="">
				<h4 class="offer-title text-white responsive-header fw-light">اختيار العمالة</h4>
			</div>
			<div class="col-lg-3 col-md-6 col-12 mb-4 text-center">
				<img src="../../images/about-3.png" class="img-fluid mb-3" alt="">
				<h4 class="offer-title text-white responsive-header fw-light">تعاقد الاستقدام</h4>
			</div>
			<div class="col-lg-3 col-md-6 col-12 mb-4 text-center">
				<img src="../../images/about-4.png" class="img-fluid mb-3" alt="">
				<h4 class="offer-title text-white responsive-header fw-light">وصول العمالة</h4>
			</div>
		</div>
	</div>
</div>
