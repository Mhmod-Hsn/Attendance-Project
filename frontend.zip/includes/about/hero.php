<div id="hero" class="">
    <div class="hero-about">

        <div class="single-slide bg-cover position-relative text-center" style="background: url('../../images/hero-about.png')">
            <div class="overlay d-flex flex-column justify-content-center align-items-center">
                <div class="text pt-lg-10 pt-md-8 pt-sm-6 pt-4 ">
                    <h2 class="slide-title text-white">بوابتك لاستقدام العمالة من باكستان</h2>
                    <p class="slide-description mt-3 text-secondary text-justify center-justify">نقدم حلولاً عالية الجودة مع خدمة لا مثيل لها لعملائنا مبنية عل الثقة والريادة
	                    وأن نكون شريكاً موثوقاً به للحلول العمالية المبتكرة</p>
                </div>
            </div>
        </div>


    </div>
</div>


