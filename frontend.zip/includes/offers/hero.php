<div id="hero" class="">
    <div class="hero-about">

        <div class="single-slide bg-cover position-relative text-center" style="background: url('../../images/offers.png')">
            <div class="overlay d-flex flex-column justify-content-center align-items-center">
                <div class="text pt-lg-10 pt-md-8 pt-sm-6 pt-4 ">
                    <h2 class="slide-title text-white">نقدم دائماً أفضل العروض والأسعار</h2>
                    <p class="slide-description mt-3 text-secondary text-justify center-justify">نسعى دائماً لإرضاء عملائنا من خلال تقديم عروض مستمرة وخصومات مميزة من خلال
	                    حساباتنا الرسمية على مواقع التواصل الإجتماعي وموقعنا الإلكتروني</p>
                </div>
            </div>
        </div>


    </div>
</div>


