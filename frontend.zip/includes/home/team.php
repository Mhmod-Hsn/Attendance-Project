<div id="team" class="p-lg-7 p-md-6 p-5">
    <div class="container">
        <h2 class="text-primary fw-bold text-center responsive-header mb-lg-6 mb-md-5 mb-4">فريق العمل</h2>

        <div id="team-slider">
            <?php for ($i=0;$i<6;$i++){ ?>
                <div class="single-slide bg-cover" style="background-image: url('../../images/team1.png')">
                    <div class="overlay d-flex flex-column justify-content-end align-items-baseline px-3">
                        <h6 class=" responsive-paragraph text-white mb-0">عادل العامري</h6>
                        <p class=" my-1 responsive-paragraph text-secondary mb-0">المدير العام</p>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>
</div>
