<div id="warning" class="my-5 my-md-4 my-3">
	<div class="container">
		<div class="row">
			<div class="col-md-6 mt-md-4 mt-3"  >
				<h2 class="text-primary fw-bold  responsive-header">تحذير هام</h2>
				<p class="responsive-paragraph">
					يحذر المكتب من التعامل مع أي شخص ينتحل صفـة
					الأستاذ عـادل العامـري فنحـن غيـر مـسـؤولـون عـن أي
					تعامل يتم مع أي شخص خارج الموقع الرسـمي أو عن
					طريق طرق التواصل والأرقام المتاحة على الموقع.
				</p>
			</div>

			<div class="col-md-6">
				<img src="../../images/passport.png" class="img-fluid" alt="">
			</div>
		</div>

	</div>
</div>
