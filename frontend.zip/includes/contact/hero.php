<div id="hero" class="">
    <div class="hero-about">

        <div class="single-slide bg-cover position-relative text-center" style="background: url('../../images/order-hero.png')">
            <div class="overlay d-flex flex-column justify-content-center align-items-center">
                <div class="text pt-lg-10 pt-md-8 pt-sm-6 pt-4 ">
                    <h2 class="slide-title text-white">حقق رغبتك في استقدام العمالة الآن</h2>
                    <p class="slide-description mt-3 text-secondary text-justify center-justify">سنقدم لك أفضل العمالة الباكستانية المناسبة والمتوافقة مع احتياجاتك مع جميع الضمانات التي تحفظ حقوق العامل وصاحب العمل</p>
                </div>
            </div>
        </div>


    </div>
</div>


