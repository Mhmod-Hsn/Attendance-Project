<div id="copyrights" class="bg-d-gray">
    <div class="container">
        <div class="d-flex justify-content-md-between flex-column flex-md-row align-items-center py-2 text-center mb-md-0">
            <div class="text-white mb-3 mb-md-0 ">
                جميع الحقوق محفوظة لصالح مكتب عادل العامري &copy; <?php echo date("Y") ?>
            </div>
            <div>
                <a class="text-secondary " href="https://www.hulultech.com.sa" target="_blank">تصميم وتطوير مؤسسة حلول تيك لتقنية المعلومات</a>
            </div>
        </div>
    </div>
</div>
