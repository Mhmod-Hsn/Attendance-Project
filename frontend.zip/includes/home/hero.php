<div id="hero" class="">
    <div class="hero-slider">

        <?php for ($i=0;$i<4;$i++){ ?>
        <div class="single-slide bg-cover position-relative text-center" style="background: url('../../images/worker.jpg')">
            <div class="overlay d-flex flex-column justify-content-center align-items-center">
                <div class="text ">
                    <h2 class="slide-title text-white">أفضل العمال المتدربين من باكستان</h2>
                    <p class="slide-description mt-3 text-secondary text-justify center-justify">نعمل على توفير الكوادر البشرية لقطاعات الأفراد والأعمال وخدمات التوسط في الاستقدام واصدار التأشيرات ، بما يتناسب مع لوائح وقوانين العمل السعودية الصادرة من وزارة العمل</p>
                </div>
            </div>
        </div>
        <?php } ?>


    </div>
</div>


