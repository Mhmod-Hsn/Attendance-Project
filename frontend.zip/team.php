
<?php include('includes/header.php') ?>


<?php include('includes/team/hero.php') ?>
<?php include('includes/team/team.php') ?>

<?php include('includes/footer.php') ?>




