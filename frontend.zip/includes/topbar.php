<div id="topbar" class="bg-offwhite py-2">
	<div class="container">
		<div class="d-flex justify-content-md-between flex-column flex-md-row align-items-center">
			<div class="contact ">
				<ul class="list-inline">
					<li class="list-inline-item mr-3">
						<i class="text-secondary fas fa-phone fa-flip-horizontal"></i>
						<a href="tel: +923015349627" class="font-en">
							00923015349627
						</a>
						<!--<span class="mx-1">|</span>
						<a href="tel: +923135404155" class="font-en">
							00923135404155
						</a>-->
					</li>
					<li class="list-inline-item mr-3">
						<a href="mailto:adil@adilalameeri.com" class="font-en">
							<i class="text-secondary fas fa-envelope"></i>
							adil@adilalameeri.com
						</a>
					</li>
				</ul>



			</div>

			<?php include 'social.php' ?>
		</div>
	</div>
</div>
