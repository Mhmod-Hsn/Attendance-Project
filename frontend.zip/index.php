
<?php include('includes/header.php') ?>


<?php include('includes/home/hero.php') ?>

<?php include('includes/home/about.php') ?>
<?php include('includes/home/services.php') ?>
<?php include('includes/home/team.php') ?>
<?php include('includes/home/what-we-offer.php') ?>
<?php include('includes/home/offers.php') ?>



<?php include('includes/footer.php') ?>




